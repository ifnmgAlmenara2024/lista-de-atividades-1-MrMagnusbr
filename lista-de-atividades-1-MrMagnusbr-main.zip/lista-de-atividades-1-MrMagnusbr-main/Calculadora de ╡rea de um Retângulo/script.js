let altura = Number(window.prompt("Escreva a altura do retangulo: "))
let base = Number(window.prompt("Escreva a base do retangulo: "))
const area = base * altura
window.alert(`A area do retangulo de base ${base} e altura ${altura} eh: ${area}`)
