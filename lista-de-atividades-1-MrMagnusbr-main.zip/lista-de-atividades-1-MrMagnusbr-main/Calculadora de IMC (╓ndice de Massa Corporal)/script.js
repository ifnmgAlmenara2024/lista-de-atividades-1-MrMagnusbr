let altura = Number(window.prompt("Escreva sua altura: "))
let peso = Number(window.prompt("Escreva seu peso: "))
let imc = peso / (altura ** 2)

if (imc < 18.5){
    window.alert("Abaixo do peso")
 }else if(imc < 24.9){
    window.alert("Peso normal")
 }else if(imc < 29.9){
    window.alert("Sobrepeso")
 }else if(imc < 34.9){
    window.alert("Obesidade I")
 }else if(imc < 39.9){
    window.alert("Obesidade II")
 }else {
    window.alert("Obesidade III")
 }
