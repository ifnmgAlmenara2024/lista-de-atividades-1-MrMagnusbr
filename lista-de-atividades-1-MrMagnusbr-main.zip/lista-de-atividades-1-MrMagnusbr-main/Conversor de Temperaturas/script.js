let temperatura = Number(window.prompt("Escreva a temperatura em Celsius: "))
let fahrenheit = (temperatura * 1.8) + 32
// let fahrenheit = (temperatura * 9/5) + 32
window.alert(`A temperatura em Fahrenheit é: ${fahrenheit}°F`)
