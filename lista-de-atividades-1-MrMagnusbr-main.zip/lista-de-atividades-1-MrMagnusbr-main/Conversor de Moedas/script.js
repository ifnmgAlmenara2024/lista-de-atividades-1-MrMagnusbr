let op, moeda1, moeda2, valori, valorf

op = Number(window.prompt("Escolha a moeda que deseja converter: \n 1- Real (BRL)\n 2- Dolar (USD)\n 3- Euro (EUR)\n 4- Libra Esterlina (GBP)\n"))
switch (op) {
    case 1:
        moeda1 = 1
        break;
    case 2:
        moeda1 = 5.5
        break
    case 3:
        moeda1 = 6.5
        break;
    case 4:
        moeda1 = 7.5
        break;
    default:
        window.alert("Opção invalida");
        break;   
}
op = Number(window.prompt("Escolha para qual moeda que deseja converter: \n 1- Real (BRL)\n 2- Dolar (USD)\n 3- Euro (EUR)\n 4- Libra Esterlina (GBP)\n"))
switch (op) {
    case 1:
        moeda2 = 1
        break;
    case 2:
        moeda2 = 5.5
        break
    case 3:
        moeda2 = 6.5
        break;
    case 4:
        moeda2 = 7.5
        break;
    default:
        window.alert("Opção invalida");
        break;   
}
valori = Number(window.prompt("Digite o valor que deseja converter: "))
valorf = (valori * moeda1) / moeda2
window.alert(`O Valor ${valori} convertido fica ${valorf}`)